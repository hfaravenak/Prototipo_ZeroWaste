import { BrowserRouter, Routes, Route } from 'react-router-dom'
import Home from './components/HomeComponent'
import Image from './components/ImageComponent'
import Report from './components/ReportComponent.jsx'
import IngredientReport from './components/IngredientReportComponent'
import ReportDownload from './components/ReportDownloadComponent'

function App() {
  return (
    <BrowserRouter>
      <Routes>
        <Route path='/' element={<Home />} />
        <Route path='/image' element={<Image />} />
        <Route path="/reportes" element={<Report />} />
        <Route path="/ingredientes" element={<IngredientReport />} />
        <Route path="/reporte-anual" element={<ReportDownload />} />
      </Routes>
    </BrowserRouter>
  )
}

export default App
